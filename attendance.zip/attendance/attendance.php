<?php session_start(); 
require 'connection.php'

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="A web based app for managing attendance using QR code">
  

  <title>Login | AttendanceQR</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

  <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <script src="vendor/jquery/jquery.min.js"></script>

  <script src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
  <script type="text/javascript" src="js/instascan.min.js"></script>
</head>

<body style="background-image: url('./images/BG_HIDDEN.jpeg'); background-repeat: no-repeat; background-size: cover;">
    
    <center>
    <div class="">
      <div class="card card-login mx-auto mt-5" style=" background: rgba(0,0,0,0.5); ">
      <div class="card-body"> 
        <form method="POST" action="storeimage.php" enctype="multipart/form-data">
    <h1 style="color: white;">ATTENDANCE | QR CODE </h1>
    
    <div>
    <video width="100%" id="preview"></video>
    </div>
<script type="text/javascript">
  
var scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
scanner.addListener('scan', function (content) {
decodedString = atob(atob(atob(content)));
url="mark.php"+decodedString;
$.ajax({
  type: "GET",
  url: url,
  success: function(data) {
    if (data == '0') {
      alert('Could not mark the attendance. Please try again later.');
    }
    if (data == '1') {
      window.location.replace('attendance.php');
    }
    if (data == '2') {
      alert('Attendance updated successfully!');
    }
    if (data == '3') {
      alert('Could not mark the attendance. QR Code Expired!');
    }
    if (data == '4') {
      alert('User does not exist!');
    }
    if (data == '5') {
      alert('Could not mark the attendance. Restricted User!');
    }
    if (data == '6') {
      alert('Attendance cannot be marked beyond shift hours!');
    }
  }
});
});
Instascan.Camera.getCameras().then(function (cameras) {
if (cameras.length == 0) {
  scanner.start(cameras[0]);
}
else if(cameras.length>0) {
  scanner.start(cameras[0]);
}
else {
  console.error('No cameras found.');
}
}).catch(function (e) {
console.error(e);
});

</script>
</form>
         
          <br>
          <a href="index.php">
          <button class="btn btn-primary btn-block" style="width:250px;">Login</button>
          </a>
        
      </div>
    </div>
    </div>
    </center>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
   <!-- Bootstrap core JavaScript-->
   <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="../vendor/chart.js/Chart.min.js"></script>
  <script src="../vendor/datatables/jquery.dataTables.js"></script>
  <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="../js/demo/datatables-demo.js"></script>
  <script src="../js/demo/chart-area-demo.js"></script>


</body>

</html>
